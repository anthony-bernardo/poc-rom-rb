CREATE FUNCTION bit_length(text)
  RETURNS integer
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.octet_length($1) * 8
$$;

