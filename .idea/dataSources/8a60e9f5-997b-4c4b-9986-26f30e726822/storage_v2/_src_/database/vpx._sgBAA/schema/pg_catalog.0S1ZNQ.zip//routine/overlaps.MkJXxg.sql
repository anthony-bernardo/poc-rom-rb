CREATE FUNCTION "overlaps"(timestamp without time zone, timestamp without time zone, timestamp without time zone, interval)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select ($1, $2) overlaps ($3, ($3 + $4))
$$;

